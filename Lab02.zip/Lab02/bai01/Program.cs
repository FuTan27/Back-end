﻿using System;

class Program
{
    static int TinhTongCacSoChan(int[] arr)
    {
        int tong = 0;
        foreach (int so in arr)
        {
            if (so % 2 == 0) // Kiểm tra xem số có phải là số chẵn không
            {
                tong += so; // Cộng số chẵn vào tổng
            }
        }
        return tong;
    }

    static void Main()
    {
        // Khai báo mảng ví dụ
        int[] mang = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        // Gọi hàm và in kết quả
        int tongCacSoChan = TinhTongCacSoChan(mang);
        Console.WriteLine("Tổng các số chẵn trong mảng là: " + tongCacSoChan);
    }
}
