using Microsoft.AspNetCore.Mvc;

namespace DaiNamCNTT.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
