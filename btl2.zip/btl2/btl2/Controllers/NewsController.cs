﻿using Microsoft.AspNetCore.Mvc;

namespace DaiNamCNTT.Controllers
{
    public class NewsController : Controller
    {
        public IActionResult All()
        {
            return View();
        }

        public IActionResult Details(int id)
        {
            ViewBag.NewsId = id;
            return View();
        }
    }
}
